Como criar e executar o servidor:

(cd Trab2_Parte_2/ && make all)
make all
./tp_server.out
./Trab2_Parte_2/Client.out tcp 127.0.0.1 1234 100 convert -paint 2  Trab2_Parte_2/Files/entradaISEL.jpg Trab2_Parte_2/temp/pintura.jpg